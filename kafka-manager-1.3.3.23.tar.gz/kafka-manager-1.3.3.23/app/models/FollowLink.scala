/**
 * Copyright 2015 Yahoo Inc. Licensed under the Apache License, Version 2.0
 * See accompanying LICENSE file.
 */

package models

/**
 * @author hiral
 */
case class FollowLink(title: String, url: String)
